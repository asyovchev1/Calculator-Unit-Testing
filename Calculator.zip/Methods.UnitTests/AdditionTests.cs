namespace Methods.UnitTests
{
    public class AdditionTests
    {
        [Test, Order(1)]
        public void Test_Add_TwoZeroes()
        {
            // Arrange
            int n1 = 0;
            int n2 = 0;

            // Act
            int result = Addition.Add(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(0));
        }

        [Test, Order(2)]
        public void Test_Add_FirstZeroSecondPositiveInteger()
        {
            // Arrange
            int n1 = 0;
            int n2 = 5;

            // Act
            int result = Addition.Add(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(5));
        }

        [Test, Order(3)]
        public void Test_Add_FirstZeroSecondNegativeInteger()
        {
            // Arrange
            int n1 = 0;
            int n2 = -4;

            // Act
            int result = Addition.Add(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(-4));
        }

        [Test, Order(4)]
        public void Test_Add_FirstPositiveIntegerSecondZero()
        {
            // Arrange
            int n1 = 6;
            int n2 = 0;

            // Act
            int result = Addition.Add(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(6));
        }

        [Test, Order(5)]
        public void Test_Add_FirstNegativeIntegerSecondZero()
        {
            // Arrange
            int n1 = -1;
            int n2 = 0;

            // Act
            int result = Addition.Add(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(-1));
        }

        [Test, Order(6)]
        public void Test_Add_TwoSamePositiveIntegers()
        {
            // Arrange
            int n1 = 14;
            int n2 = 14;

            // Act
            int result = Addition.Add(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(28));
        }

        [Test, Order(7)]
        public void Test_Add_TwoSameNegativeIntegers()
        {
            // Arrange
            int n1 = -17;
            int n2 = -17;

            // Act
            int result = Addition.Add(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(-34));
        }

        [Test, Order(8)]
        public void Test_Add_TwoPositiveIntegers()
        {
            // Arrange
            int n1 = 12;
            int n2 = 4;

            // Act
            int result = Addition.Add(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(16));
        }

        [Test, Order(9)]
        public void Test_Add_FirstPositiveIntegerSecondNegativeInteger()
        {
            // Arrange
            int n1 = 12;
            int n2 = -3;

            // Act
            int result = Addition.Add(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(9));
        }

        [Test, Order(10)]
        public void Test_Add_FirstNegativeIntegerSecondPositiveInteger()
        {
            // Arrange
            int n1 = -1;
            int n2 = 8;

            // Act
            int result = Addition.Add(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(7));
        }

        [Test, Order(11)]
        public void Test_Add_TwoNegativeIntegers()
        {
            // Arrange
            int n1 = -1;
            int n2 = -9;

            // Act
            int result = Addition.Add(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(-10));
        }
    }
}