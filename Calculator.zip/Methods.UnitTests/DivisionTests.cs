﻿using NUnit.Framework.Constraints;

namespace Methods.UnitTests
{
    public class DivisionTests
    {
        [Test, Order(1)]
        public void Test_Divide_TwoZeros()
        {
            // Arrange
            int n1 = 0;
            int n2 = 0;

            // Act
            double result = Division.Divide(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(double.NaN));
        }

        [Test, Order(2)]
        public void Test_Divide_ZeroPositive()
        {
            // Arrange
            int n1 = 0;
            int n2 = 1;

            // Act
            double result = Division.Divide(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(0));
        }

        [Test, Order(3)]
        public void Test_Divide_ZeroNegative()
        {
            // Arrange
            int n1 = 0;
            int n2 = -1;

            // Act
            double result = Division.Divide(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(-0));
        }

        [Test, Order(4)]
        public void Test_Divide_PositiveZero()
        {
            // Arrange
            int n1 = 1;
            int n2 = 0;

            // Act
            double result = Division.Divide(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(double.PositiveInfinity));
        }

        [Test, Order(5)]
        public void Test_Divide_NegativeZero()
        {
            // Arrange
            int n1 = -1;
            int n2 = 0;

            // Act
            double result = Division.Divide(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(double.NegativeInfinity));
        }

        [Test, Order(6)]
        public void Test_Divide_TwoSamePositive()
        {
            // Arrange
            int n1 = 43;
            int n2 = 43;

            // Act
            double result = Division.Divide(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(1));
        }

        [Test, Order(7)]
        public void Test_Divide_TwoSameNegative()
        {
            // Arrange
            int n1 = -11;
            int n2 = -11;

            // Act
            double result = Division.Divide(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(1));
        }

        [Test, Order(8)]
        public void Test_Divide_TwoPositive()
        {
            // Arrange
            int n1 = 45;
            int n2 = 13;

            // Act
            double result = Math.Round(Division.Divide(n1, n2), 7);

            // Assert
            Assert.That(result, Is.EqualTo(3.4615385d));
        }

        [Test, Order(9)]
        public void Test_Divide_TwoNegative()
        {
            // Arrange
            int n1 = -21;
            int n2 = -13;

            // Act
            double result = Math.Round(Division.Divide(n1, n2), 7);

            // Assert
            Assert.That(result, Is.EqualTo(1.6153846d));
        }

        [Test, Order(10)]
        public void Test_Divide_PositiveNegative()
        {
            // Arrange
            int n1 = 45;
            int n2 = -9;

            // Act
            double result = Division.Divide(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(-5d));
        }

        [Test, Order(11)]
        public void Test_Divide_NegativePositive()
        {
            // Arrange
            int n1 = -66;
            int n2 = 11;

            // Act
            double result = Division.Divide(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(-6d));
        }
    }
}
