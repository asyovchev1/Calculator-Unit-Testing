﻿namespace Methods.UnitTests
{
    public class MultiplicationTests
    {
        [Test, Order(1)]
        public void Test_Multiply_TwoZeros()
        {
            // Arrange
            int n1 = 0;
            int n2 = 0;

            // Act
            int result = Multiplication.Multiply(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(0));
        }

        [Test, Order(2)]
        public void Test_Multiply_ZeroPositiveInteger()
        {
            // Arrange
            int n1 = 0;
            int n2 = 1;

            // Act
            int result = Multiplication.Multiply(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(0));
        }

        [Test, Order(3)]
        public void Test_Multiply_ZeroNegativeInteger()
        {
            // Arrange
            int n1 = 0;
            int n2 = -1;

            // Act
            int result = Multiplication.Multiply(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(0));
        }

        [Test, Order(4)]
        public void Test_Multiply_PositiveIntegerZero()
        {
            // Arrange
            int n1 = 1;
            int n2 = 0;

            // Act
            int result = Multiplication.Multiply(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(0));
        }

        [Test, Order(5)]
        public void Test_Multiply_NegativeIntegerZero()
        {
            // Arrange
            int n1 = -1;
            int n2 = 0;

            // Act
            int result = Multiplication.Multiply(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(0));
        }

        [Test, Order(6)]
        public void Test_Multiply_TwoSamePositiveIntegers()
        {
            // Arrange
            int n1 = 43;
            int n2 = 43;

            // Act
            int result = Multiplication.Multiply(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(1849));
        }

        [Test, Order(7)]
        public void Test_Multiply_TwoSameNegativeIntegers()
        {
            // Arrange
            int n1 = -11;
            int n2 = -11;

            // Act
            int result = Multiplication.Multiply(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(121));
        }

        [Test, Order(8)]
        public void Test_Multiply_TwoPositiveIntegers()
        {
            // Arrange
            int n1 = 12;
            int n2 = 13;

            // Act
            int result = Multiplication.Multiply(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(156));
        }

        [Test, Order(9)]
        public void Test_Multiply_TwoNegativeIntegers()
        {
            // Arrange
            int n1 = -7;
            int n2 = -6;

            // Act
            int result = Multiplication.Multiply(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(42));
        }

        [Test, Order(10)]
        public void Test_Multiply_PositiveNegativeIntegers()
        {
            // Arrange
            int n1 = 45;
            int n2 = -10;

            // Act
            int result = Multiplication.Multiply(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(-450));
        }

        [Test, Order(11)]
        public void Test_Multiply_NegativePositiveIntegers()
        {
            // Arrange
            int n1 = -66;
            int n2 = 10;

            // Act
            int result = Multiplication.Multiply(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(-660));
        }
    }
}
