﻿namespace Methods.UnitTests
{
    public class SubtractionTests
    {
        [Test, Order(1)]
        public void Test_Subtract_TwoZeros()
        {
            // Arrange
            int n1 = 0;
            int n2 = 0;

            // Act
            int result = Subtraction.Subtract(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(0));
        }

        [Test, Order(2)]
        public void Test_Subtract_FirstZeroSecondPositiveInteger()
        {
            // Arrange
            int n1 = 0;
            int n2 = 5;

            // Act
            int result = Subtraction.Subtract(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(-5));
        }

        [Test, Order(3)]
        public void Test_Subtract_FirstZeroSecondNegativeInteger()
        {
            // Arrange
            int n1 = 0;
            int n2 = -4;

            // Act
            int result = Subtraction.Subtract(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(4));
        }

        [Test, Order(4)]
        public void Test_Subtract_FirstPositiveIntegerSecondZero()
        {
            // Arrange
            int n1 = 10;
            int n2 = 0;

            // Act
            int result = Subtraction.Subtract(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(10));
        }

        [Test, Order(5)]
        public void Test_Subtract_FirstNegativeIntegerSecondZero()
        {
            // Arrange
            int n1 = -7;
            int n2 = 0;

            // Act
            int result = Subtraction.Subtract(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(-7));
        }

        [Test, Order(6)]
        public void Test_Subtract_TwoSamePositiveIntegers()
        {
            // Arrange
            int n1 = 51;
            int n2 = 51;

            // Act
            int result = Subtraction.Subtract(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(0));
        }

        [Test, Order(7)]
        public void Test_Subtract_TwoSameNegativeIntegers()
        {
            // Arrange
            int n1 = -23;
            int n2 = -23;

            // Act
            int result = Subtraction.Subtract(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(0));
        }

        [Test, Order(8)]
        public void Test_Subtract_TwoPositiveIntegers()
        {
            // Arrange
            int n1 = 23;
            int n2 = 4;

            // Act
            int result = Subtraction.Subtract(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(19));
        }

        [Test, Order(9)]
        public void Test_Subtract_FirstPositiveIntegerSecondNegativeInteger()
        {
            // Arrange
            int n1 = 18;
            int n2 = -4;

            // Act
            int result = Subtraction.Subtract(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(22));
        }

        [Test, Order(10)]
        public void Test_Subtract_FirstNegativeIntegerSecondPositiveInteger()
        {
            /// Arrange
            int n1 = -9;
            int n2 = 5;

            // Act
            int result = Subtraction.Subtract(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(-14));
        }

        [Test, Order(11)]
        public void Test_Subtract_TwoNegativeIntegers()
        {
            // Arrange
            int n1 = -17;
            int n2 = -13;

            // Act
            int result = Subtraction.Subtract(n1, n2);

            // Assert
            Assert.That(result, Is.EqualTo(-4));
        }
    }
}
