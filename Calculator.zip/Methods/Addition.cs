﻿namespace Methods
{
    public class Addition
    {
        public static int Add(int a, int b)
        {
            return a + b;
        }
    }
}
