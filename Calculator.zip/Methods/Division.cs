﻿namespace Methods
{
    public class Division
    {
        public static double Divide(int a, int b)
        {
            return (double)a / b;
        }
    }
}
