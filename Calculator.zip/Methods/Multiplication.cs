﻿namespace Methods
{
    public class Multiplication
    {
        public static int Multiply(int a, int b)
        {
            return a * b;
        }
    }
}
