﻿namespace Methods
{
    public class Subtraction
    {
        public static int Subtract(int a, int b)
        {
            return a - b;
        }
    }
}
